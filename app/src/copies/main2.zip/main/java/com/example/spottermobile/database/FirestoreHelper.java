package com.example.spottermobile.database;

import android.util.Log;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;
import com.google.firebase.firestore.Transaction;
import com.example.spottermobile.model.User;
import com.example.spottermobile.model.Booking;
import com.example.spottermobile.model.WorkoutHistory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FirestoreHelper {
    private static final String TAG = "FirestoreHelper";
    private FirebaseFirestore db;

    // Collection names
    private static final String USERS_COLLECTION = "users";
    private static final String BOOKINGS_COLLECTION = "bookings";
    private static final String WAITLIST_COLLECTION = "waitlist";

    public FirestoreHelper() {
        db = FirebaseFirestore.getInstance();
    }

    // ==================== USER OPERATIONS ====================

    /**
     * Register a new user
     */
    public void registerUser(String name, String email, String username, String hashedPassword,
                             String userType, FirestoreCallback<String> callback) {
        Map<String, Object> user = new HashMap<>();
        user.put("name", name);
        user.put("email", email);
        user.put("username", username);
        user.put("password", hashedPassword);
        user.put("userType", userType); // "member" or "admin"
        user.put("isSuspended", false);
        user.put("createdAt", System.currentTimeMillis());

        db.collection(USERS_COLLECTION)
                .add(user)
                .addOnSuccessListener(docRef -> {
                    Log.d(TAG, "User registered with ID: " + docRef.getId());
                    callback.onSuccess(docRef.getId());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error registering user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Check if username already exists
     */
    public void isUserExists(String username, FirestoreCallback<Boolean> callback) {
        db.collection(USERS_COLLECTION)
                .whereEqualTo("username", username)
                .get()
                .addOnSuccessListener(snapshot -> {
                    callback.onSuccess(!snapshot.isEmpty());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking user existence", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Login user — find by username and password
     */
    public void loginUser(String identifier, String hashedPassword, FirestoreCallback<User> callback) {
        db.collection(USERS_COLLECTION)
                .whereEqualTo("username", identifier)
                .whereEqualTo("password", hashedPassword)
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (!snapshot.isEmpty()) {
                        DocumentSnapshot doc = snapshot.getDocuments().get(0);
                        User user = doc.toObject(User.class);
                        if (user != null) {
                            user.setId(doc.getId());
                            callback.onSuccess(user);
                        } else {
                            callback.onFailure("Failed to parse user");
                        }
                    } else {
                        callback.onFailure("User not found");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error logging in", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get user by ID
     */
    public void getUserById(String userId, FirestoreCallback<User> callback) {
        db.collection(USERS_COLLECTION)
                .document(userId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        User user = doc.toObject(User.class);
                        if (user != null) {
                            user.setId(doc.getId());
                            callback.onSuccess(user);
                        } else {
                            callback.onFailure("Failed to parse user");
                        }
                    } else {
                        callback.onFailure("User not found");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get all users (for admin)
     */
    public void getAllUsers(FirestoreCallback<List<User>> callback) {
        db.collection(USERS_COLLECTION)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<User> users = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        User user = doc.toObject(User.class);
                        if (user != null) {
                            user.setId(doc.getId());
                            users.add(user);
                        }
                    }
                    callback.onSuccess(users);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting all users", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Suspend a user
     */
    public void suspendUser(String userId, FirestoreCallback<Void> callback) {
        db.collection(USERS_COLLECTION)
                .document(userId)
                .update("isSuspended", true)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "User suspended: " + userId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error suspending user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== BOOKING OPERATIONS ====================

    /**
     * Add a booking (with capacity check using transaction)
     */
    public void addBooking(String userId, String timeSlot, String date, String gymName,
                           FirestoreCallback<String> callback) {
        db.runTransaction((Transaction.Function<String>) transaction -> {
            // 1. Check slot capacity
            int bookedCount = 0;
            QuerySnapshot bookingSnapshot = transaction.get(
                    db.collection(BOOKINGS_COLLECTION)
                            .whereEqualTo("timeSlot", timeSlot)
                            .whereEqualTo("date", date)
                            .whereIn("status", List.of("confirmed", "checked_in"))
            );
            bookedCount = bookingSnapshot.size();

            // 2. Check daily cap for user
            QuerySnapshot dailySnapshot = transaction.get(
                    db.collection(BOOKINGS_COLLECTION)
                            .whereEqualTo("userId", userId)
                            .whereEqualTo("date", date)
                            .whereIn("status", List.of("confirmed", "checked_in"))
            );
            int dailyCount = dailySnapshot.size();

            String status = "confirmed";
            if (bookedCount >= 15) { // 15 is slot capacity
                status = "waitlisted";
            } else if (dailyCount >= 3) { // 3 bookings per day max
                status = "waitlisted";
            }

            // 3. Create booking
            Map<String, Object> booking = new HashMap<>();
            booking.put("userId", userId);
            booking.put("timeSlot", timeSlot);
            booking.put("date", date);
            booking.put("gymName", gymName);
            booking.put("status", status);
            booking.put("paymentStatus", "pending");
            booking.put("checkinTime", 0);
            booking.put("checkoutTime", 0);
            booking.put("createdAt", System.currentTimeMillis());

            String docId = db.collection(BOOKINGS_COLLECTION).document().getId();
            transaction.set(db.collection(BOOKINGS_COLLECTION).document(docId), booking);

            return docId;
        }).addOnSuccessListener(bookingId -> {
            Log.d(TAG, "Booking added: " + bookingId);
            callback.onSuccess(bookingId);
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Error adding booking", e);
            callback.onFailure(e.getMessage());
        });
    }

    /**
     * Get all bookings for a user
     */
    public void getUserBookings(String userId, FirestoreCallback<List<Booking>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Booking> bookings = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Booking booking = doc.toObject(Booking.class);
                        if (booking != null) {
                            booking.setId(doc.getId());
                            bookings.add(booking);
                        }
                    }
                    callback.onSuccess(bookings);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting user bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get bookings by status for a user
     */
    public void getBookingsByStatus(String userId, String status, FirestoreCallback<List<Booking>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .whereEqualTo("status", status)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Booking> bookings = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Booking booking = doc.toObject(Booking.class);
                        if (booking != null) {
                            booking.setId(doc.getId());
                            bookings.add(booking);
                        }
                    }
                    callback.onSuccess(bookings);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting bookings by status", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Cancel a booking
     */
    public void cancelBooking(String bookingId, FirestoreCallback<Void> callback) {
        db.runTransaction((Transaction.Function<Void>) transaction -> {
            // 1. Update booking to cancelled
            transaction.update(db.collection(BOOKINGS_COLLECTION).document(bookingId), "status", "cancelled");

            // 2. Check if there's a waitlisted user for this slot
            DocumentSnapshot bookingDoc = transaction.get(
                    db.collection(BOOKINGS_COLLECTION).document(bookingId)
            );
            String timeSlot = (String) bookingDoc.get("timeSlot");
            String date = (String) bookingDoc.get("date");

            QuerySnapshot waitlistSnapshot = transaction.get(
                    db.collection(WAITLIST_COLLECTION)
                            .whereEqualTo("timeSlot", timeSlot)
                            .whereEqualTo("date", date)
                            .limit(1)
            );

            if (!waitlistSnapshot.isEmpty()) {
                DocumentSnapshot waitlistDoc = waitlistSnapshot.getDocuments().get(0);
                String waitlistedUserId = (String) waitlistDoc.get("userId");

                // Promote waitlisted user
                Map<String, Object> promotion = new HashMap<>();
                promotion.put("userId", waitlistedUserId);
                promotion.put("timeSlot", timeSlot);
                promotion.put("date", date);
                promotion.put("gymName", (String) bookingDoc.get("gymName"));
                promotion.put("status", "confirmed");
                promotion.put("paymentStatus", "pending");
                promotion.put("checkinTime", 0);
                promotion.put("checkoutTime", 0);
                promotion.put("createdAt", System.currentTimeMillis());

                String newBookingId = db.collection(BOOKINGS_COLLECTION).document().getId();
                transaction.set(db.collection(BOOKINGS_COLLECTION).document(newBookingId), promotion);

                // Remove from waitlist
                transaction.delete(db.collection(WAITLIST_COLLECTION).document(waitlistDoc.getId()));
            }

            return null;
        }).addOnSuccessListener(aVoid -> {
            Log.d(TAG, "Booking cancelled: " + bookingId);
            callback.onSuccess(null);
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Error cancelling booking", e);
            callback.onFailure(e.getMessage());
        });
    }

    /**
     * Check in a booking
     */
    public void checkInBooking(String bookingId, FirestoreCallback<Void> callback) {
        long checkinTime = System.currentTimeMillis();
        db.collection(BOOKINGS_COLLECTION)
                .document(bookingId)
                .update(
                        "status", "checked_in",
                        "checkinTime", checkinTime
                )
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Booking checked in: " + bookingId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking in booking", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Check out a booking
     */
    public void checkOutBooking(String bookingId, FirestoreCallback<Void> callback) {
        long checkoutTime = System.currentTimeMillis();
        db.runTransaction((Transaction.Function<Void>) transaction -> {
            DocumentSnapshot bookingDoc = transaction.get(
                    db.collection(BOOKINGS_COLLECTION).document(bookingId)
            );

            // Update booking status
            transaction.update(db.collection(BOOKINGS_COLLECTION).document(bookingId),
                    "status", "completed",
                    "checkoutTime", checkoutTime
            );

            // Record workout history
            Map<String, Object> history = new HashMap<>();
            history.put("userId", bookingDoc.get("userId"));
            history.put("date", bookingDoc.get("date"));
            history.put("timeSlot", bookingDoc.get("timeSlot"));
            history.put("gymName", bookingDoc.get("gymName"));
            history.put("duration", checkoutTime - (long) bookingDoc.get("checkinTime"));
            history.put("recordedAt", System.currentTimeMillis());

            String historyId = db.collection("workoutHistory").document().getId();
            transaction.set(db.collection("workoutHistory").document(historyId), history);

            return null;
        }).addOnSuccessListener(aVoid -> {
            Log.d(TAG, "Booking checked out: " + bookingId);
            callback.onSuccess(null);
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Error checking out booking", e);
            callback.onFailure(e.getMessage());
        });
    }

    /**
     * Get slot booking count
     */
    public void getSlotBookingCount(String timeSlot, String date, FirestoreCallback<Integer> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("timeSlot", timeSlot)
                .whereEqualTo("date", date)
                .whereIn("status", List.of("confirmed", "checked_in"))
                .get()
                .addOnSuccessListener(snapshot -> {
                    callback.onSuccess(snapshot.size());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting slot booking count", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== WAITLIST OPERATIONS ====================

    /**
     * Add user to waitlist
     */
    public void addToWaitlist(String userId, String timeSlot, String date, String gymName,
                              FirestoreCallback<Void> callback) {
        Map<String, Object> waitlistEntry = new HashMap<>();
        waitlistEntry.put("userId", userId);
        waitlistEntry.put("timeSlot", timeSlot);
        waitlistEntry.put("date", date);
        waitlistEntry.put("gymName", gymName);
        waitlistEntry.put("addedAt", System.currentTimeMillis());

        db.collection(WAITLIST_COLLECTION)
                .add(waitlistEntry)
                .addOnSuccessListener(docRef -> {
                    Log.d(TAG, "User added to waitlist: " + userId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error adding to waitlist", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get waitlist for a time slot
     */
    public void getWaitlist(String timeSlot, String date, FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(WAITLIST_COLLECTION)
                .whereEqualTo("timeSlot", timeSlot)
                .whereEqualTo("date", date)
                .orderBy("addedAt", com.google.firebase.firestore.Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Map<String, Object>> waitlist = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Map<String, Object> entry = doc.getData();
                        if (entry != null) {
                            entry.put("id", doc.getId());
                            waitlist.add(entry);
                        }
                    }
                    callback.onSuccess(waitlist);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting waitlist", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== ADMIN OPERATIONS ====================

    /**
     * Get all bookings with user details (for admin)
     */
    public void getAllBookingsWithNames(FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Map<String, Object>> bookingsWithNames = new ArrayList<>();
                    List<DocumentSnapshot> docs = snapshot.getDocuments();

                    for (DocumentSnapshot doc : docs) {
                        String userId = (String) doc.get("userId");
                        // Fetch user details
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    if (userDoc.exists()) {
                                        Map<String, Object> bookingData = doc.getData();
                                        if (bookingData != null) {
                                            bookingData.put("id", doc.getId());
                                            bookingData.put("userName", (String) userDoc.get("name"));
                                            bookingData.put("userEmail", (String) userDoc.get("email"));
                                            bookingsWithNames.add(bookingData);
                                        }
                                    }
                                });
                    }

                    // Note: This is not ideal — we're doing N+1 queries
                    // For production, consider using Cloud Functions or batching
                    callback.onSuccess(bookingsWithNames);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting all bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get filtered bookings (by date range, status, etc.)
     */
    public void getFilteredBookingsWithNames(String status, String date,
                                             FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("status", status)
                .whereEqualTo("date", date)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Map<String, Object>> bookingsWithNames = new ArrayList<>();

                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        String userId = (String) doc.get("userId");
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    if (userDoc.exists()) {
                                        Map<String, Object> bookingData = doc.getData();
                                        if (bookingData != null) {
                                            bookingData.put("id", doc.getId());
                                            bookingData.put("userName", (String) userDoc.get("name"));
                                            bookingData.put("userEmail", (String) userDoc.get("email"));
                                            bookingsWithNames.add(bookingData);
                                        }
                                    }
                                });
                    }

                    callback.onSuccess(bookingsWithNames);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting filtered bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get total revenue (paid bookings)
     */
    public void getTotalRevenue(FirestoreCallback<Double> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("paymentStatus", "paid")
                .get()
                .addOnSuccessListener(snapshot -> {
                    double total = snapshot.size() * 200.0; // 200 per booking
                    callback.onSuccess(total);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting revenue", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get paid bookings with user details
     */
    public void getPaidBookingsWithNames(FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("paymentStatus", "paid")
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Map<String, Object>> bookingsWithNames = new ArrayList<>();

                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        String userId = (String) doc.get("userId");
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    if (userDoc.exists()) {
                                        Map<String, Object> bookingData = doc.getData();
                                        if (bookingData != null) {
                                            bookingData.put("id", doc.getId());
                                            bookingData.put("userName", (String) userDoc.get("name"));
                                            bookingData.put("userEmail", (String) userDoc.get("email"));
                                            bookingsWithNames.add(bookingData);
                                        }
                                    }
                                });
                    }

                    callback.onSuccess(bookingsWithNames);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting paid bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Mark booking as paid
     */
    public void markBookingAsPaid(String bookingId, FirestoreCallback<Void> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .document(bookingId)
                .update("paymentStatus", "paid")
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Booking marked as paid: " + bookingId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error marking booking as paid", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get workout history for a user
     */
    public void getWorkoutHistory(String userId, FirestoreCallback<List<WorkoutHistory>> callback) {
        db.collection("workoutHistory")
                .whereEqualTo("userId", userId)
                .orderBy("recordedAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<WorkoutHistory> histories = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        WorkoutHistory history = doc.toObject(WorkoutHistory.class);
                        if (history != null) {
                            history.setId(doc.getId());
                            histories.add(history);
                        }
                    }
                    callback.onSuccess(histories);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting workout history", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== CALLBACK INTERFACE ====================

    public interface FirestoreCallback<T> {
        void onSuccess(T result);
        void onFailure(String errorMessage);
    }
}