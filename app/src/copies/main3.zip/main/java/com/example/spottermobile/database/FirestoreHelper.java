package com.example.spottermobile.database;

import android.util.Log;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;
import com.google.firebase.firestore.Transaction;
import com.example.spottermobile.model.User;
import com.example.spottermobile.model.Booking;
import com.example.spottermobile.model.WorkoutHistory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FirestoreHelper {
    private static final String TAG = "FirestoreHelper";
    private FirebaseFirestore db;

    // Collection names
    private static final String USERS_COLLECTION    = "users";
    private static final String BOOKINGS_COLLECTION = "bookings";
    private static final String WAITLIST_COLLECTION = "waitlist";

    public FirestoreHelper() {
        db = FirebaseFirestore.getInstance();
    }

    // ==================== USER OPERATIONS ====================

    /**
     * Register a new user.
     */
    public void registerUser(String name, String email, String username, String hashedPassword,
                             String userType, FirestoreCallback<String> callback) {
        Map<String, Object> user = new HashMap<>();
        user.put("name",        name);
        user.put("fullName",    name);   // stored under both keys for toObject() mapping
        user.put("email",       email);
        user.put("username",    username);
        user.put("password",    hashedPassword);
        user.put("userType",    userType); // "member" or "admin"
        user.put("isSuspended", false);
        user.put("createdAt",   System.currentTimeMillis());

        db.collection(USERS_COLLECTION)
                .add(user)
                .addOnSuccessListener(docRef -> {
                    Log.d(TAG, "User registered with ID: " + docRef.getId());
                    callback.onSuccess(docRef.getId());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error registering user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Check if username already exists.
     */
    public void isUserExists(String username, FirestoreCallback<Boolean> callback) {
        db.collection(USERS_COLLECTION)
                .whereEqualTo("username", username)
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(!snapshot.isEmpty()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking user existence", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Login user — find by username and password.
     */
    public void loginUser(String identifier, String hashedPassword, FirestoreCallback<User> callback) {
        db.collection(USERS_COLLECTION)
                .whereEqualTo("username", identifier)
                .whereEqualTo("password", hashedPassword)
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (!snapshot.isEmpty()) {
                        DocumentSnapshot doc = snapshot.getDocuments().get(0);
                        User user = docToUser(doc);
                        if (user != null) callback.onSuccess(user);
                        else              callback.onFailure("Failed to parse user");
                    } else {
                        callback.onFailure("User not found");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error logging in", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get user by Firestore document ID.
     */
    public void getUserById(String userId, FirestoreCallback<User> callback) {
        db.collection(USERS_COLLECTION)
                .document(userId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        User user = docToUser(doc);
                        if (user != null) callback.onSuccess(user);
                        else              callback.onFailure("Failed to parse user");
                    } else {
                        callback.onFailure("User not found");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get all users (for admin).
     */
    public void getAllUsers(FirestoreCallback<List<User>> callback) {
        db.collection(USERS_COLLECTION)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<User> users = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        User user = docToUser(doc);
                        if (user != null) users.add(user);
                    }
                    callback.onSuccess(users);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting all users", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Count users whose userType == "member".
     * Used by AdminDashboardActivity's Total Members stat card.
     */
    public void getMemberCount(FirestoreCallback<Integer> callback) {
        db.collection(USERS_COLLECTION)
                .whereEqualTo("userType", "member")
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting member count", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Suspend a user (set isSuspended = true).
     */
    public void suspendUser(String userId, FirestoreCallback<Void> callback) {
        db.collection(USERS_COLLECTION)
                .document(userId)
                .update("isSuspended", true)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "User suspended: " + userId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error suspending user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Unsuspend a user (set isSuspended = false).
     * Used by MemberDetailActivity to reinstate a suspended member.
     */
    public void unsuspendUser(String userId, FirestoreCallback<Void> callback) {
        db.collection(USERS_COLLECTION)
                .document(userId)
                .update("isSuspended", false)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "User unsuspended: " + userId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error unsuspending user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== BOOKING OPERATIONS ====================

    /**
     * Add a booking (with capacity check using transaction).
     */
    public void addBooking(String userId, String timeSlot, String date, String gymName,
                           FirestoreCallback<String> callback) {
        db.runTransaction((Transaction.Function<String>) transaction -> {
            // 1. Check slot capacity
            QuerySnapshot bookingSnapshot = transaction.get(
                    db.collection(BOOKINGS_COLLECTION)
                            .whereEqualTo("timeSlot", timeSlot)
                            .whereEqualTo("date", date)
                            .whereIn("status", List.of("confirmed", "checked_in"))
            );
            int bookedCount = bookingSnapshot.size();

            // 2. Check daily cap for user
            QuerySnapshot dailySnapshot = transaction.get(
                    db.collection(BOOKINGS_COLLECTION)
                            .whereEqualTo("userId", userId)
                            .whereEqualTo("date", date)
                            .whereIn("status", List.of("confirmed", "checked_in"))
            );
            int dailyCount = dailySnapshot.size();

            String status = "confirmed";
            if (bookedCount >= 15) {      // 15 is slot capacity
                status = "waitlisted";
            } else if (dailyCount >= 3) { // 3 bookings per day max
                status = "waitlisted";
            }

            // 3. Create booking document
            Map<String, Object> booking = new HashMap<>();
            booking.put("userId",       userId);
            booking.put("timeSlot",     timeSlot);
            booking.put("date",         date);
            booking.put("gymName",      gymName);
            booking.put("status",       status);
            booking.put("paymentStatus", "pending");
            booking.put("checkinTime",  0);
            booking.put("checkoutTime", 0);
            booking.put("createdAt",    System.currentTimeMillis());

            String docId = db.collection(BOOKINGS_COLLECTION).document().getId();
            transaction.set(db.collection(BOOKINGS_COLLECTION).document(docId), booking);

            return docId;
        }).addOnSuccessListener(bookingId -> {
            Log.d(TAG, "Booking added: " + bookingId);
            callback.onSuccess(bookingId);
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Error adding booking", e);
            callback.onFailure(e.getMessage());
        });
    }

    /**
     * Get all bookings for a user, newest first.
     */
    public void getUserBookings(String userId, FirestoreCallback<List<Booking>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Booking> bookings = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Booking b = docToBooking(doc);
                        if (b != null) bookings.add(b);
                    }
                    callback.onSuccess(bookings);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting user bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get bookings by status for a user.
     */
    public void getBookingsByStatus(String userId, String status,
                                    FirestoreCallback<List<Booking>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .whereEqualTo("status", status)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Booking> bookings = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Booking b = docToBooking(doc);
                        if (b != null) bookings.add(b);
                    }
                    callback.onSuccess(bookings);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting bookings by status", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Count bookings on a given date that match any of the provided statuses.
     * Used by AdminDashboardActivity stat cards and the 7-day bar chart.
     *
     * @param date     yyyy-MM-dd string
     * @param statuses list of status values to include (e.g. ["confirmed","checked_in"])
     */
    public void getBookingsByDateAndStatuses(String date, List<String> statuses,
                                             FirestoreCallback<Integer> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("date", date)
                .whereIn("status", statuses)
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting bookings by date+statuses", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Cancel a booking and promote the first waitlisted user for that slot (if any).
     */
    public void cancelBooking(String bookingId, FirestoreCallback<Void> callback) {
        db.runTransaction((Transaction.Function<Void>) transaction -> {
            // 1. Read the booking to get slot info before updating
            DocumentSnapshot bookingDoc = transaction.get(
                    db.collection(BOOKINGS_COLLECTION).document(bookingId)
            );
            String timeSlot = (String) bookingDoc.get("timeSlot");
            String date     = (String) bookingDoc.get("date");

            // 2. Mark the booking as cancelled
            transaction.update(
                    db.collection(BOOKINGS_COLLECTION).document(bookingId),
                    "status", "cancelled"
            );

            // 3. Promote the first waitlisted user for this slot (if any)
            QuerySnapshot waitlistSnapshot = transaction.get(
                    db.collection(WAITLIST_COLLECTION)
                            .whereEqualTo("timeSlot", timeSlot)
                            .whereEqualTo("date", date)
                            .limit(1)
            );

            if (!waitlistSnapshot.isEmpty()) {
                DocumentSnapshot waitlistDoc = waitlistSnapshot.getDocuments().get(0);
                String waitlistedUserId = (String) waitlistDoc.get("userId");

                Map<String, Object> promotion = new HashMap<>();
                promotion.put("userId",        waitlistedUserId);
                promotion.put("timeSlot",      timeSlot);
                promotion.put("date",          date);
                promotion.put("gymName",       bookingDoc.get("gymName"));
                promotion.put("status",        "confirmed");
                promotion.put("paymentStatus", "pending");
                promotion.put("checkinTime",   0);
                promotion.put("checkoutTime",  0);
                promotion.put("createdAt",     System.currentTimeMillis());

                String newBookingId = db.collection(BOOKINGS_COLLECTION).document().getId();
                transaction.set(db.collection(BOOKINGS_COLLECTION).document(newBookingId), promotion);
                transaction.delete(db.collection(WAITLIST_COLLECTION).document(waitlistDoc.getId()));
            }

            return null;
        }).addOnSuccessListener(aVoid -> {
            Log.d(TAG, "Booking cancelled: " + bookingId);
            callback.onSuccess(null);
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Error cancelling booking", e);
            callback.onFailure(e.getMessage());
        });
    }

    /**
     * Check in a booking.
     */
    public void checkInBooking(String bookingId, FirestoreCallback<Void> callback) {
        long checkinTime = System.currentTimeMillis();
        db.collection(BOOKINGS_COLLECTION)
                .document(bookingId)
                .update(
                        "status",      "checked_in",
                        "checkinTime", checkinTime
                )
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Booking checked in: " + bookingId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking in booking", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Check out a booking and record workout history.
     */
    public void checkOutBooking(String bookingId, FirestoreCallback<Void> callback) {
        long checkoutTime = System.currentTimeMillis();
        db.runTransaction((Transaction.Function<Void>) transaction -> {
            DocumentSnapshot bookingDoc = transaction.get(
                    db.collection(BOOKINGS_COLLECTION).document(bookingId)
            );

            transaction.update(db.collection(BOOKINGS_COLLECTION).document(bookingId),
                    "status",        "completed",
                    "checkoutTime",  checkoutTime
            );

            Map<String, Object> history = new HashMap<>();
            history.put("userId",     bookingDoc.get("userId"));
            history.put("date",       bookingDoc.get("date"));
            history.put("timeSlot",   bookingDoc.get("timeSlot"));
            history.put("gymName",    bookingDoc.get("gymName"));
            history.put("duration",   checkoutTime - (long) bookingDoc.get("checkinTime"));
            history.put("recordedAt", System.currentTimeMillis());

            String historyId = db.collection("workoutHistory").document().getId();
            transaction.set(db.collection("workoutHistory").document(historyId), history);

            return null;
        }).addOnSuccessListener(aVoid -> {
            Log.d(TAG, "Booking checked out: " + bookingId);
            callback.onSuccess(null);
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Error checking out booking", e);
            callback.onFailure(e.getMessage());
        });
    }

    /**
     * Get the count of confirmed/checked-in bookings for a specific slot.
     */
    public void getSlotBookingCount(String timeSlot, String date,
                                    FirestoreCallback<Integer> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("timeSlot", timeSlot)
                .whereEqualTo("date",     date)
                .whereIn("status",        List.of("confirmed", "checked_in"))
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting slot booking count", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== WAITLIST OPERATIONS ====================

    /**
     * Add user to waitlist.
     */
    public void addToWaitlist(String userId, String timeSlot, String date, String gymName,
                              FirestoreCallback<Void> callback) {
        Map<String, Object> entry = new HashMap<>();
        entry.put("userId",   userId);
        entry.put("timeSlot", timeSlot);
        entry.put("date",     date);
        entry.put("gymName",  gymName);
        entry.put("addedAt",  System.currentTimeMillis());

        db.collection(WAITLIST_COLLECTION)
                .add(entry)
                .addOnSuccessListener(docRef -> {
                    Log.d(TAG, "User added to waitlist: " + userId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error adding to waitlist", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get the ordered waitlist for a time slot.
     */
    public void getWaitlist(String timeSlot, String date,
                            FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(WAITLIST_COLLECTION)
                .whereEqualTo("timeSlot", timeSlot)
                .whereEqualTo("date",     date)
                .orderBy("addedAt", com.google.firebase.firestore.Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Map<String, Object>> waitlist = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Map<String, Object> e = doc.getData();
                        if (e != null) {
                            e.put("id", doc.getId());
                            waitlist.add(e);
                        }
                    }
                    callback.onSuccess(waitlist);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting waitlist", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== ADMIN OPERATIONS ====================

    /**
     * Get all bookings with user name/email joined in (N+1 fetches).
     * Results are returned once ALL user lookups have completed.
     *
     * Note: for large datasets consider a Cloud Function or denormalising
     * userName into the booking document at write time.
     */
    public void getAllBookingsWithNames(FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<DocumentSnapshot> docs = snapshot.getDocuments();
                    if (docs.isEmpty()) {
                        callback.onSuccess(new ArrayList<>());
                        return;
                    }

                    // Use an array so lambda can write to it
                    final List<Map<String, Object>> results =
                            new java.util.concurrent.CopyOnWriteArrayList<>();
                    final java.util.concurrent.atomic.AtomicInteger remaining =
                            new java.util.concurrent.atomic.AtomicInteger(docs.size());

                    for (DocumentSnapshot doc : docs) {
                        String userId = (String) doc.get("userId");
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  userDoc.exists() ? userDoc.getString("fullName") : "Unknown");
                                        data.put("userEmail", userDoc.exists() ? userDoc.getString("email")    : "");
                                    }
                                    if (data != null) results.add(data);
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                })
                                .addOnFailureListener(e -> {
                                    // Still add the booking without user info
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  "Unknown");
                                        data.put("userEmail", "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting all bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get bookings filtered by status AND date with user names joined in.
     */
    public void getFilteredBookingsWithNames(String status, String date,
                                             FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("status", status)
                .whereEqualTo("date",   date)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<DocumentSnapshot> docs = snapshot.getDocuments();
                    if (docs.isEmpty()) {
                        callback.onSuccess(new ArrayList<>());
                        return;
                    }

                    final List<Map<String, Object>> results =
                            new java.util.concurrent.CopyOnWriteArrayList<>();
                    final java.util.concurrent.atomic.AtomicInteger remaining =
                            new java.util.concurrent.atomic.AtomicInteger(docs.size());

                    for (DocumentSnapshot doc : docs) {
                        String userId = (String) doc.get("userId");
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  userDoc.exists() ? userDoc.getString("fullName") : "Unknown");
                                        data.put("userEmail", userDoc.exists() ? userDoc.getString("email")    : "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                })
                                .addOnFailureListener(e -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  "Unknown");
                                        data.put("userEmail", "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting filtered bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get total revenue from paid bookings (₱200 per booking).
     */
    public void getTotalRevenue(FirestoreCallback<Double> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("paymentStatus", "paid")
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size() * 200.0))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting revenue", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get all paid bookings with user names joined in.
     * Used by AdminDashboardActivity revenue table and AdminRevenueActivity.
     */
    public void getPaidBookingsWithNames(FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("paymentStatus", "paid")
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<DocumentSnapshot> docs = snapshot.getDocuments();
                    if (docs.isEmpty()) {
                        callback.onSuccess(new ArrayList<>());
                        return;
                    }

                    final List<Map<String, Object>> results =
                            new java.util.concurrent.CopyOnWriteArrayList<>();
                    final java.util.concurrent.atomic.AtomicInteger remaining =
                            new java.util.concurrent.atomic.AtomicInteger(docs.size());

                    for (DocumentSnapshot doc : docs) {
                        String userId = (String) doc.get("userId");
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  userDoc.exists() ? userDoc.getString("fullName") : "Unknown");
                                        data.put("userEmail", userDoc.exists() ? userDoc.getString("email")    : "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                })
                                .addOnFailureListener(e -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  "Unknown");
                                        data.put("userEmail", "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting paid bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Mark a booking as paid.
     */
    public void markBookingAsPaid(String bookingId, FirestoreCallback<Void> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .document(bookingId)
                .update("paymentStatus", "paid")
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Booking marked as paid: " + bookingId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error marking booking as paid", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get workout history for a user, newest first.
     */
    public void getWorkoutHistory(String userId, FirestoreCallback<List<WorkoutHistory>> callback) {
        db.collection("workoutHistory")
                .whereEqualTo("userId", userId)
                .orderBy("recordedAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<WorkoutHistory> histories = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        WorkoutHistory h = doc.toObject(WorkoutHistory.class);
                        if (h != null) {
                            h.setId(doc.getId());
                            histories.add(h);
                        }
                    }
                    callback.onSuccess(histories);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting workout history", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== PRIVATE HELPERS ====================

    /**
     * Maps a Firestore DocumentSnapshot to a User object, handling both
     * "name" and "fullName" field variants and setting the Firestore doc ID.
     */
    private User docToUser(DocumentSnapshot doc) {
        User user = doc.toObject(User.class);
        if (user == null) return null;

        user.setFirestoreId(doc.getId());

        // Firestore may store name under "name" only; patch fullName if missing
        if (user.getFullName() == null || user.getFullName().isEmpty()) {
            String name = doc.getString("name");
            if (name != null) user.setFullName(name);
        }

        // Normalise userType → role
        if (user.getUserType() == null && user.getRole() != null) {
            user.setUserType("admin".equals(user.getRole()) ? "admin" : "member");
        }

        return user;
    }

    /**
     * Maps a Firestore DocumentSnapshot to a Booking object and sets the doc ID.
     * Also maps the Firestore "date" field → selectedDate and "gymName" → workoutType.
     */
    private Booking docToBooking(DocumentSnapshot doc) {
        Booking booking = doc.toObject(Booking.class);
        if (booking == null) return null;

        booking.setId(doc.getId()); // String version

        // "date" → selectedDate
        if (booking.getSelectedDate() == null) {
            String date = doc.getString("date");
            if (date != null) booking.setSelectedDate(date);
        }

        // "gymName" → workoutType (reused in adapters for gym/slot display)
        if (booking.getWorkoutType() == null) {
            String gym = doc.getString("gymName");
            if (gym != null) booking.setWorkoutType(gym);
        }

        // userId stored as String in Firestore
        String userIdStr = doc.getString("userId");
        if (userIdStr != null) booking.setUserIdStr(userIdStr);

        return booking;
    }

    // ==================== CALLBACK INTERFACE ====================

    public interface FirestoreCallback<T> {
        void onSuccess(T result);
        void onFailure(String errorMessage);
    }
}