package com.example.spottermobile.database;

import android.util.Log;

import com.example.spottermobile.model.Booking;
import com.example.spottermobile.model.User;
import com.example.spottermobile.model.WorkoutHistory;
import com.example.spottermobile.utils.SlotUtils;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class FirestoreHelper {

    private static final String TAG = "FirestoreHelper";

    private final FirebaseFirestore db;

    // Collection names
    private static final String USERS_COLLECTION    = "users";
    private static final String BOOKINGS_COLLECTION = "bookings";
    private static final String WAITLIST_COLLECTION = "waitlist";
    private static final String HISTORY_COLLECTION  = "workoutHistory";

    public FirestoreHelper() {
        db = FirebaseFirestore.getInstance();
    }

    // ==================== USER OPERATIONS ====================

    public void seedAdminIfNotExists() {
        db.collection("users")
                .whereEqualTo("username", "admin")
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.isEmpty()) {
                        Map<String, Object> admin = new HashMap<>();
                        admin.put("username", "admin");
                        admin.put("password", "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9");
                        admin.put("userType", "admin");
                        admin.put("role", "admin");
                        admin.put("fullName", "Administrator");
                        admin.put("email", "admin@spotter.com");
                        admin.put("isSuspended", false);
                        admin.put("createdAt", System.currentTimeMillis());
                        db.collection("users").add(admin);
                    }
                });
    }
    /**
     * Register a new user.
     */
    public void registerUser(String name, String email, String username, String hashedPassword,
                             String userType, FirestoreCallback<String> callback) {
        Map<String, Object> user = new HashMap<>();
        user.put("name",        name);
        user.put("fullName",    name);
        user.put("email",       email);
        user.put("username",    username);
        user.put("password",    hashedPassword);
        user.put("userType",    userType);
        user.put("isSuspended", false);
        user.put("createdAt",   System.currentTimeMillis());

        db.collection(USERS_COLLECTION)
                .add(user)
                .addOnSuccessListener(docRef -> {
                    Log.d(TAG, "User registered: " + docRef.getId());
                    callback.onSuccess(docRef.getId());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error registering user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Check if username already exists.
     */
    public void isUserExists(String username, FirestoreCallback<Boolean> callback) {
        db.collection(USERS_COLLECTION)
                .whereEqualTo("username", username)
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(!snapshot.isEmpty()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking user existence", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Login user — find by username and password.
     */
    public void loginUser(String identifier, String hashedPassword,
                          FirestoreCallback<User> callback) {
        db.collection(USERS_COLLECTION)
                .whereEqualTo("username", identifier)
                .whereEqualTo("password", hashedPassword)
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (!snapshot.isEmpty()) {
                        User user = docToUser(snapshot.getDocuments().get(0));
                        if (user != null) callback.onSuccess(user);
                        else              callback.onFailure("Failed to parse user");
                    } else {
                        callback.onFailure("User not found");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error logging in", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get user by Firestore document ID.
     */
    public void getUserById(String userId, FirestoreCallback<User> callback) {
        db.collection(USERS_COLLECTION)
                .document(userId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        User user = docToUser(doc);
                        if (user != null) callback.onSuccess(user);
                        else              callback.onFailure("Failed to parse user");
                    } else {
                        callback.onFailure("User not found");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get all users (for admin).
     */
    public void getAllUsers(FirestoreCallback<List<User>> callback) {
        db.collection(USERS_COLLECTION)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<User> users = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        User user = docToUser(doc);
                        if (user != null) users.add(user);
                    }
                    callback.onSuccess(users);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting all users", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Count users whose userType == "member".
     */
    public void getMemberCount(FirestoreCallback<Integer> callback) {
        db.collection(USERS_COLLECTION)
                .whereEqualTo("userType", "member")
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting member count", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Suspend a user (set isSuspended = true).
     */
    public void suspendUser(String userId, FirestoreCallback<Void> callback) {
        db.collection(USERS_COLLECTION)
                .document(userId)
                .update("isSuspended", true)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "User suspended: " + userId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error suspending user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Unsuspend a user (set isSuspended = false).
     */
    public void unsuspendUser(String userId, FirestoreCallback<Void> callback) {
        db.collection(USERS_COLLECTION)
                .document(userId)
                .update("isSuspended", false)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "User unsuspended: " + userId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error unsuspending user", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== BOOKING OPERATIONS ====================

    /**
     * Add a booking with capacity check.
     * FIXED: queries run OUTSIDE any transaction — Firestore transactions only
     * accept DocumentReference in transaction.get(), not Query objects.
     */
    public void addBooking(String userId, String timeSlot, String date, String gymName,
                           FirestoreCallback<String> callback) {
        // Step 1: check slot capacity
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("timeSlot", timeSlot)
                .whereEqualTo("date", date)
                .whereIn("status", Arrays.asList("confirmed", "checked_in"))
                .get()
                .addOnSuccessListener(slotSnapshot -> {
                    int bookedCount = slotSnapshot.size();

                    // Step 2: check daily cap for user
                    db.collection(BOOKINGS_COLLECTION)
                            .whereEqualTo("userId", userId)
                            .whereEqualTo("date", date)
                            .whereIn("status", Arrays.asList("confirmed", "checked_in"))
                            .get()
                            .addOnSuccessListener(dailySnapshot -> {
                                int dailyCount = dailySnapshot.size();

                                String status = "confirmed";
                                if (bookedCount >= 15 || dailyCount >= 3) {
                                    status = "waitlisted";
                                }

                                final String finalStatus = status;
                                String docId = db.collection(BOOKINGS_COLLECTION).document().getId();

                                Map<String, Object> booking = new HashMap<>();
                                booking.put("userId",        userId);
                                booking.put("timeSlot",      timeSlot);
                                booking.put("date",          date);
                                booking.put("gymName",       gymName);
                                booking.put("status",        finalStatus);
                                booking.put("paymentStatus", "pending");
                                booking.put("checkinTime",   0);
                                booking.put("checkoutTime",  0);
                                booking.put("createdAt",     System.currentTimeMillis());

                                db.collection(BOOKINGS_COLLECTION).document(docId)
                                        .set(booking)
                                        .addOnSuccessListener(v -> {
                                            Log.d(TAG, "Booking added: " + docId);
                                            callback.onSuccess(docId);
                                        })
                                        .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
                            })
                            .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
                })
                .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
    }

    /**
     * Get a single booking by its Firestore document ID.
     */
    public void getBookingById(String bookingId, FirestoreCallback<Booking> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .document(bookingId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        Booking b = docToBooking(doc);
                        if (b != null) callback.onSuccess(b);
                        else           callback.onFailure("Failed to parse booking");
                    } else {
                        callback.onFailure("Booking not found");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting booking by ID", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Fetch the current status string of a booking doc.
     * Used by AutoCheckoutReceiver and AutoCheckoutWorker.
     */
    public void getBookingStatus(String bookingId, FirestoreCallback<String> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .document(bookingId)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        String status = doc.getString("status");
                        callback.onSuccess(status != null ? status : "");
                    } else {
                        callback.onFailure("Booking not found: " + bookingId);
                    }
                })
                .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
    }

    /**
     * Get all bookings for a user, newest first.
     */
    public void getUserBookings(String userId, FirestoreCallback<List<Booking>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Booking> bookings = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Booking b = docToBooking(doc);
                        if (b != null) bookings.add(b);
                    }
                    callback.onSuccess(bookings);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting user bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get bookings by status for a specific user.
     */
    public void getBookingsByStatus(String userId, String status,
                                    FirestoreCallback<List<Booking>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .whereEqualTo("status", status)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Booking> bookings = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Booking b = docToBooking(doc);
                        if (b != null) bookings.add(b);
                    }
                    callback.onSuccess(bookings);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting bookings by status", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Fetch ALL bookings across all users with a given status.
     * Used by BookingNotificationReceiver on BOOT_COMPLETED to reschedule
     * auto-checkout alarms for every checked-in booking in the system.
     */
    public void getAllBookingsByStatus(String status, FirestoreCallback<List<Booking>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("status", status)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Booking> bookings = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Booking b = docToBooking(doc);
                        if (b != null) bookings.add(b);
                    }
                    callback.onSuccess(bookings);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "getAllBookingsByStatus failed", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Count bookings on a given date that match any of the provided statuses.
     * Used by AdminDashboardActivity stat cards and the 7-day bar chart.
     */
    public void getBookingsByDateAndStatuses(String date, List<String> statuses,
                                             FirestoreCallback<Integer> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("date", date)
                .whereIn("status", statuses)
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting bookings by date+statuses", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Returns true if the user has any booking with status "confirmed" or "checked_in".
     * Used by BookingActivity to block double-booking.
     */
    public void hasAnyActiveBooking(String userId, FirestoreCallback<Boolean> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .whereIn("status", Arrays.asList("confirmed", "checked_in"))
                .limit(1)
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(!snapshot.isEmpty()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking active booking", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Returns true if the user already has a booking on the given date.
     * Prevents same-day duplicate bookings.
     */
    public void isUserBookedOnDate(String userId, String date,
                                   FirestoreCallback<Boolean> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("userId", userId)
                .whereEqualTo("date",   date)
                .whereIn("status",      Arrays.asList("confirmed", "checked_in", "waitlisted"))
                .limit(1)
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(!snapshot.isEmpty()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking date booking", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Returns true if the user is already on the waitlist for a specific slot.
     */
    public void isUserWaitlistedForSlot(String userId, String date, String timeSlot,
                                        FirestoreCallback<Boolean> callback) {
        db.collection(WAITLIST_COLLECTION)
                .whereEqualTo("userId",   userId)
                .whereEqualTo("date",     date)
                .whereEqualTo("timeSlot", timeSlot)
                .limit(1)
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(!snapshot.isEmpty()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking waitlist", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get count of confirmed/checked-in bookings for a specific slot.
     * Used by BookingActivity to show availability.
     */
    public void getSlotBookingCount(String timeSlot, String date,
                                    FirestoreCallback<Integer> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("timeSlot", timeSlot)
                .whereEqualTo("date",     date)
                .whereIn("status",        Arrays.asList("confirmed", "checked_in"))
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting slot booking count", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get count of confirmed/checked-in bookings for the whole day.
     * Used to enforce MAX_DAILY_CAPACITY.
     */
    public void getDailyBookingCount(String date, FirestoreCallback<Integer> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("date",  date)
                .whereIn("status",     Arrays.asList("confirmed", "checked_in"))
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting daily booking count", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Cancel a booking and promote the first waitlisted user for that slot (if any).
     * FIXED: queries run outside the transaction using a WriteBatch for the writes.
     */
    public void cancelBooking(String bookingId, FirestoreCallback<Void> callback) {
        // Step 1: read booking doc to get slot info
        db.collection(BOOKINGS_COLLECTION).document(bookingId).get()
                .addOnSuccessListener(bookingDoc -> {
                    if (!bookingDoc.exists()) {
                        callback.onFailure("Booking not found");
                        return;
                    }
                    String timeSlot = bookingDoc.getString("timeSlot");
                    String date     = bookingDoc.getString("date");

                    // Step 2: query waitlist outside transaction
                    db.collection(WAITLIST_COLLECTION)
                            .whereEqualTo("timeSlot", timeSlot)
                            .whereEqualTo("date",     date)
                            .limit(1)
                            .get()
                            .addOnSuccessListener(waitlistSnapshot -> {
                                WriteBatch batch = db.batch();

                                // Cancel the booking
                                batch.update(
                                        db.collection(BOOKINGS_COLLECTION).document(bookingId),
                                        "status", "cancelled"
                                );

                                // Promote first waitlisted user if any
                                if (!waitlistSnapshot.isEmpty()) {
                                    DocumentSnapshot waitlistDoc =
                                            waitlistSnapshot.getDocuments().get(0);
                                    String waitlistedUserId = waitlistDoc.getString("userId");

                                    Map<String, Object> promotion = new HashMap<>();
                                    promotion.put("userId",        waitlistedUserId);
                                    promotion.put("timeSlot",      timeSlot);
                                    promotion.put("date",          date);
                                    promotion.put("gymName",       bookingDoc.get("gymName"));
                                    promotion.put("status",        "confirmed");
                                    promotion.put("paymentStatus", "pending");
                                    promotion.put("checkinTime",   0);
                                    promotion.put("checkoutTime",  0);
                                    promotion.put("createdAt",     System.currentTimeMillis());

                                    String newBookingId =
                                            db.collection(BOOKINGS_COLLECTION).document().getId();
                                    batch.set(
                                            db.collection(BOOKINGS_COLLECTION).document(newBookingId),
                                            promotion
                                    );
                                    batch.delete(waitlistDoc.getReference());
                                }

                                batch.commit()
                                        .addOnSuccessListener(v -> {
                                            Log.d(TAG, "Booking cancelled: " + bookingId);
                                            callback.onSuccess(null);
                                        })
                                        .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
                            })
                            .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
                })
                .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
    }

    /**
     * Check in a booking.
     */
    public void checkInBooking(String bookingId, FirestoreCallback<Void> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .document(bookingId)
                .update(
                        "status",      "checked_in",
                        "checkinTime", System.currentTimeMillis()
                )
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Booking checked in: " + bookingId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking in booking", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Check out a booking and record workout history.
     * Uses a transaction to atomically update the booking and write history —
     * both reads here are DocumentReference reads, which IS valid in a transaction.
     */
    public void checkOutBooking(String bookingId, FirestoreCallback<Void> callback) {
        long checkoutTime = System.currentTimeMillis();
        db.runTransaction(transaction -> {
            DocumentSnapshot bookingDoc = transaction.get(
                    db.collection(BOOKINGS_COLLECTION).document(bookingId)
            );

            transaction.update(
                    db.collection(BOOKINGS_COLLECTION).document(bookingId),
                    "status",       "completed",
                    "checkoutTime", checkoutTime
            );

            Map<String, Object> history = new HashMap<>();
            history.put("userId",     bookingDoc.get("userId"));
            history.put("date",       bookingDoc.get("date"));
            history.put("timeSlot",   bookingDoc.get("timeSlot"));
            history.put("gymName",    bookingDoc.get("gymName"));
            history.put("duration",   checkoutTime - (long) bookingDoc.get("checkinTime"));
            history.put("recordedAt", System.currentTimeMillis());

            String historyId = db.collection(HISTORY_COLLECTION).document().getId();
            transaction.set(db.collection(HISTORY_COLLECTION).document(historyId), history);

            return null;
        }).addOnSuccessListener(aVoid -> {
            Log.d(TAG, "Booking checked out: " + bookingId);
            callback.onSuccess(null);
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Error checking out booking", e);
            callback.onFailure(e.getMessage());
        });
    }

    /**
     * Create a confirmed booking with payment info in a single Firestore write.
     * BookingActivity has already validated capacity before calling this.
     */
    public void createBookingWithPayment(String userId, String timeSlot, String date,
                                         String workoutType, String paymentReference,
                                         String paymentMethod,
                                         FirestoreCallback<String> callback) {
        Map<String, Object> booking = new HashMap<>();
        booking.put("userId",           userId);
        booking.put("timeSlot",         timeSlot);
        booking.put("date",             date);
        booking.put("gymName",          workoutType);
        booking.put("status",           "confirmed");
        booking.put("paymentStatus",    "paid");
        booking.put("paymentReference", paymentReference != null ? paymentReference : "");
        booking.put("paymentMethod",    paymentMethod    != null ? paymentMethod    : "");
        booking.put("checkinTime",      0);
        booking.put("checkoutTime",     0);
        booking.put("createdAt",        System.currentTimeMillis());

        db.collection(BOOKINGS_COLLECTION)
                .add(booking)
                .addOnSuccessListener(docRef -> {
                    Log.d(TAG, "Booking created: " + docRef.getId());
                    callback.onSuccess(docRef.getId());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error creating booking", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Mark a booking as paid.
     */
    public void markBookingAsPaid(String bookingId, FirestoreCallback<Void> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .document(bookingId)
                .update("paymentStatus", "paid")
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Booking marked as paid: " + bookingId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error marking booking as paid", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Marks no-shows for all slots whose grace period has expired.
     * Firestore equivalent of DatabaseHelper.markNoShowsForAllLockedSlots().
     * Called by NoShowWorker every 30 minutes.
     */
    public void markNoShowsForAllLockedSlots(FirestoreCallback<Integer> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("status", "booked")
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.isEmpty()) {
                        callback.onSuccess(0);
                        return;
                    }

                    List<DocumentSnapshot> expired = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        String date     = doc.getString("selectedDate");
                        String timeSlot = doc.getString("timeSlot");
                        if (date == null || timeSlot == null) continue;

                        Calendar slotStart = SlotUtils.getSlotStartCalendar(date, timeSlot);
                        if (slotStart == null) continue;

                        Calendar graceEnd = (Calendar) slotStart.clone();
                        graceEnd.add(Calendar.MINUTE, SlotUtils.GRACE_PERIOD_MINUTES);

                        if (Calendar.getInstance().after(graceEnd)) {
                            expired.add(doc);
                        }
                    }

                    if (expired.isEmpty()) {
                        callback.onSuccess(0);
                        return;
                    }

                    WriteBatch batch = db.batch();
                    for (DocumentSnapshot doc : expired) {
                        batch.update(doc.getReference(), "status", "no_show");
                    }

                    batch.commit()
                            .addOnSuccessListener(v -> {
                                Log.d(TAG, "Marked " + expired.size() + " no-shows");
                                callback.onSuccess(expired.size());
                            })
                            .addOnFailureListener(e -> {
                                Log.e(TAG, "markNoShowsForAllLockedSlots batch failed", e);
                                callback.onFailure(e.getMessage());
                            });
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "markNoShowsForAllLockedSlots query failed", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== WAITLIST OPERATIONS ====================

    /**
     * Add user to waitlist (basic, no workout type).
     */
    public void addToWaitlist(String userId, String timeSlot, String date, String gymName,
                              FirestoreCallback<Void> callback) {
        Map<String, Object> entry = new HashMap<>();
        entry.put("userId",   userId);
        entry.put("timeSlot", timeSlot);
        entry.put("date",     date);
        entry.put("gymName",  gymName);
        entry.put("addedAt",  System.currentTimeMillis());

        db.collection(WAITLIST_COLLECTION)
                .add(entry)
                .addOnSuccessListener(docRef -> {
                    Log.d(TAG, "User added to waitlist: " + userId);
                    callback.onSuccess(null);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error adding to waitlist", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Add user to waitlist with workoutType, stored as a booking doc with
     * status="waitlisted". Used by BookingActivity.
     */
    public void addToWaitlistWithWorkout(String userId, String timeSlot, String date,
                                         String workoutType,
                                         FirestoreCallback<String> callback) {
        Map<String, Object> entry = new HashMap<>();
        entry.put("userId",    userId);
        entry.put("timeSlot",  timeSlot);
        entry.put("date",      date);
        entry.put("gymName",   workoutType);
        entry.put("status",    "waitlisted");
        entry.put("addedAt",   System.currentTimeMillis());
        entry.put("createdAt", System.currentTimeMillis());

        db.collection(BOOKINGS_COLLECTION)
                .add(entry)
                .addOnSuccessListener(docRef -> {
                    Log.d(TAG, "Added to waitlist (booking doc): " + docRef.getId());
                    callback.onSuccess(docRef.getId());
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error adding to waitlist", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get the ordered waitlist for a time slot.
     */
    public void getWaitlist(String timeSlot, String date,
                            FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(WAITLIST_COLLECTION)
                .whereEqualTo("timeSlot", timeSlot)
                .whereEqualTo("date",     date)
                .orderBy("addedAt", Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<Map<String, Object>> waitlist = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        Map<String, Object> e = doc.getData();
                        if (e != null) {
                            e.put("id", doc.getId());
                            waitlist.add(e);
                        }
                    }
                    callback.onSuccess(waitlist);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting waitlist", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get count of waitlisted entries for a slot.
     * Used by BookingActivity to show "You'll be #N on the waitlist".
     */
    public void getWaitlistCount(String timeSlot, String date,
                                 FirestoreCallback<Integer> callback) {
        db.collection(WAITLIST_COLLECTION)
                .whereEqualTo("timeSlot", timeSlot)
                .whereEqualTo("date",     date)
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size()))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting waitlist count", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Delete the waitlist/booking entry for a (bookingId, userId) pair.
     * Called by BookingAdapter when a member long-presses a waitlisted booking.
     */
    public void cancelWaitlistEntry(String bookingId, String userId,
                                    FirestoreCallback<Void> callback) {
        db.collection(WAITLIST_COLLECTION)
                .whereEqualTo("bookingId", bookingId)
                .whereEqualTo("userId",    userId)
                .limit(1)
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.isEmpty()) {
                        callback.onSuccess(null);
                        return;
                    }
                    snapshot.getDocuments().get(0).getReference()
                            .delete()
                            .addOnSuccessListener(v -> callback.onSuccess(null))
                            .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
                })
                .addOnFailureListener(e -> callback.onFailure(e.getMessage()));
    }

    // ==================== ADMIN OPERATIONS ====================

    /**
     * Get all bookings with user name/email joined in (N+1 fetches).
     */
    public void getAllBookingsWithNames(FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<DocumentSnapshot> docs = snapshot.getDocuments();
                    if (docs.isEmpty()) {
                        callback.onSuccess(new ArrayList<>());
                        return;
                    }

                    final List<Map<String, Object>> results = new CopyOnWriteArrayList<>();
                    final AtomicInteger remaining = new AtomicInteger(docs.size());

                    for (DocumentSnapshot doc : docs) {
                        String userId = doc.getString("userId");
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  userDoc.exists() ? userDoc.getString("fullName") : "Unknown");
                                        data.put("userEmail", userDoc.exists() ? userDoc.getString("email")    : "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                })
                                .addOnFailureListener(e -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  "Unknown");
                                        data.put("userEmail", "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting all bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get bookings filtered by status AND date with user names joined in.
     */
    public void getFilteredBookingsWithNames(String status, String date,
                                             FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("status", status)
                .whereEqualTo("date",   date)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<DocumentSnapshot> docs = snapshot.getDocuments();
                    if (docs.isEmpty()) {
                        callback.onSuccess(new ArrayList<>());
                        return;
                    }

                    final List<Map<String, Object>> results = new CopyOnWriteArrayList<>();
                    final AtomicInteger remaining = new AtomicInteger(docs.size());

                    for (DocumentSnapshot doc : docs) {
                        String userId = doc.getString("userId");
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  userDoc.exists() ? userDoc.getString("fullName") : "Unknown");
                                        data.put("userEmail", userDoc.exists() ? userDoc.getString("email")    : "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                })
                                .addOnFailureListener(e -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  "Unknown");
                                        data.put("userEmail", "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting filtered bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get total revenue from paid bookings (₱200 per booking).
     */
    public void getTotalRevenue(FirestoreCallback<Double> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("paymentStatus", "paid")
                .get()
                .addOnSuccessListener(snapshot -> callback.onSuccess(snapshot.size() * 200.0))
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting revenue", e);
                    callback.onFailure(e.getMessage());
                });
    }

    /**
     * Get all paid bookings with user names joined in.
     */
    public void getPaidBookingsWithNames(FirestoreCallback<List<Map<String, Object>>> callback) {
        db.collection(BOOKINGS_COLLECTION)
                .whereEqualTo("paymentStatus", "paid")
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<DocumentSnapshot> docs = snapshot.getDocuments();
                    if (docs.isEmpty()) {
                        callback.onSuccess(new ArrayList<>());
                        return;
                    }

                    final List<Map<String, Object>> results = new CopyOnWriteArrayList<>();
                    final AtomicInteger remaining = new AtomicInteger(docs.size());

                    for (DocumentSnapshot doc : docs) {
                        String userId = doc.getString("userId");
                        db.collection(USERS_COLLECTION).document(userId).get()
                                .addOnSuccessListener(userDoc -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  userDoc.exists() ? userDoc.getString("fullName") : "Unknown");
                                        data.put("userEmail", userDoc.exists() ? userDoc.getString("email")    : "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                })
                                .addOnFailureListener(e -> {
                                    Map<String, Object> data = doc.getData();
                                    if (data != null) {
                                        data.put("id",        doc.getId());
                                        data.put("userName",  "Unknown");
                                        data.put("userEmail", "");
                                        results.add(data);
                                    }
                                    if (remaining.decrementAndGet() == 0)
                                        callback.onSuccess(new ArrayList<>(results));
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting paid bookings", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== WORKOUT HISTORY ====================

    /**
     * Get workout history for a user, newest first.
     */
    public void getWorkoutHistory(String userId,
                                  FirestoreCallback<List<WorkoutHistory>> callback) {
        db.collection(HISTORY_COLLECTION)
                .whereEqualTo("userId", userId)
                .orderBy("recordedAt", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<WorkoutHistory> histories = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        WorkoutHistory h = doc.toObject(WorkoutHistory.class);
                        if (h != null) {
                            h.setId(doc.getId());
                            histories.add(h);
                        }
                    }
                    callback.onSuccess(histories);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting workout history", e);
                    callback.onFailure(e.getMessage());
                });
    }

    // ==================== PRIVATE HELPERS ====================

    private User docToUser(DocumentSnapshot doc) {
        User user = doc.toObject(User.class);
        if (user == null) return null;

        user.setFirestoreId(doc.getId());

        if (user.getFullName() == null || user.getFullName().isEmpty()) {
            String name = doc.getString("name");
            if (name != null) user.setFullName(name);
        }

        if (user.getUserType() == null && user.getRole() != null) {
            user.setUserType("admin".equals(user.getRole()) ? "admin" : "member");
        }

        return user;
    }

    private Booking docToBooking(DocumentSnapshot doc) {
        Booking booking = doc.toObject(Booking.class);
        if (booking == null) return null;

        booking.setId(doc.getId());

        if (booking.getSelectedDate() == null) {
            String date = doc.getString("date");
            if (date != null) booking.setSelectedDate(date);
        }

        if (booking.getWorkoutType() == null) {
            String gym = doc.getString("gymName");
            if (gym != null) booking.setWorkoutType(gym);
        }

        String userIdStr = doc.getString("userId");
        if (userIdStr != null) booking.setUserIdStr(userIdStr);

        return booking;
    }

    // ==================== CALLBACK INTERFACE ====================

    public interface FirestoreCallback<T> {
        void onSuccess(T result);
        void onFailure(String errorMessage);
    }
}